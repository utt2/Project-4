public class Stock extends Asset {
    private Double fiveYear;
    private Double oneYear;
    private Double ninetyDays;
    private Double returnValue;

    public Stock(String symbol, String name, Double fiveYear, Double oneYear, Double ninetyDays, Double returnValue) {
        super(symbol, name);
        this.fiveYear = fiveYear;
        this.oneYear = oneYear;
        this.ninetyDays = ninetyDays;
        this.returnValue = returnValue;
    }

    @Override
    public int calcValue(int initialInvestment, int years) {
        double returns = getReturns();
        return (int) Math.round(initialInvestment * Math.pow(1 + returns, years));
    }

    @Override
    public double getReturns() {
        if (fiveYear != null) {
            return (0.6 * fiveYear) + (0.2 * oneYear) + (0.2 * ninetyDays);
        } else {
            return returnValue != null ? returnValue : 0;
        }
    }
}