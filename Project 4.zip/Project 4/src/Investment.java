public class Investment {
    Asset asset;
    private int amount;
    private int years;

    public Investment(Asset asset, int amount, int years) {
        this.asset = asset;
        this.amount = amount;
        this.years = years;
    }

    public int getAmount() {
        return amount;
    }

    public int getReturnsValue() {
        return asset.calcValue(amount, years);
    }
}