import java.util.ArrayList;
import java.util.List;

public class InvestmentAccount {
    private List<Investment> investments;

    public InvestmentAccount() {
        investments = new ArrayList<>();
    }

    public void addInvestments(Investment investment) {
        investments.add(investment);
    }

    public List<Investment> getInvestments() {
        return investments;
    }

    public double getTotalInvestments() {
        return investments.stream().mapToDouble(Investment::getAmount).sum();
    }

    public double getTotalValue() {
        return investments.stream().mapToDouble(Investment::getReturnsValue).sum();
    }
}