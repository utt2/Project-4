import java.io.*;
import java.util.*;

public class Main {
    private static List<Asset> allAssets = new ArrayList<>();

    private static void readAssetsFromFile(String fileName) {
        try (BufferedReader br = new BufferedReader(new FileReader(fileName))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",");
                String symbol = parts[0].trim();
                String name = parts[1].trim();
                
                try {
                    if (parts.length == 3) {
                        double expectedReturn = Double.parseDouble(parts[2].trim());
                        allAssets.add(new Stock(symbol, name, null, null, null, expectedReturn));
                    } else if (parts.length >= 5) {
                        Double fiveYear = parseDouble(parts[2]);
                        Double oneYear = parseDouble(parts[3]);
                        Double ninetyDays = parseDouble(parts[4]);
                        allAssets.add(new Stock(symbol, name, fiveYear, oneYear, ninetyDays, null));
                    }
                } catch (NumberFormatException ex) {
                    System.out.println("Format issue on line " + line);
                }
            }
        } catch (IOException ex) {
            System.err.println("Error " + ex.getMessage());
        }
    }

    private static void showAssets() {
        System.out.println("Available assets for investment:");
        System.out.println("-------------------------------");
        for (Asset asset : allAssets) {
            System.out.println(asset.getName() + " (" + asset.getSymbol() + ")");
        }
        System.out.println("-------------------------------");
    }

    private static double parseDouble(String value) {
        try {
            return Double.parseDouble(value);
        } catch (NumberFormatException ex) {
            return 0;
        }
    }

    private static void showInvestments(InvestmentAccount account, PrintWriter writer, boolean toConsole) {
        PrintWriter pw = toConsole ? new PrintWriter(System.out, true) : writer;
        
        pw.println("+--------------+-----------------+--------------------+");
        pw.println("| ASSET SYMBOL | AMOUNT INVESTED | VALUE IN TEN YEARS |");
        pw.println("+==============+=================+====================+");
        
        for (Investment investment : account.getInvestments()) {
        	pw.printf("| %-12s | %-15s | %-18s |\n", investment.asset.getSymbol(), String.valueOf(investment.getAmount()), String.valueOf(investment.getReturnsValue()));
        }
        
        pw.println("+--------------+-----------------+--------------------+");
        
        int totalInvestment = 0;
        int totalValue = 0;
        for (Investment investment : account.getInvestments()) {
            totalInvestment += investment.getAmount();
            totalValue += investment.getReturnsValue();
        }
        
        pw.printf("| TOTAL        | %-15d | %-18d |\n", totalInvestment, totalValue);
        pw.println("+--------------+-----------------+--------------------+");
    }

    private static void writeToFile(InvestmentAccount account) {
        try (PrintWriter pw = new PrintWriter(new FileWriter("portfolio.txt"))) {
        	showInvestments(account, pw, false);
        } catch (IOException ex) {
            System.err.println("Error writing to .txt" /*+*/);
        }
    }
    
    public static void main(String[] args) {
        try {
            readAssetsFromFile("src/assetData.csv");
        } catch (Exception ex) {
            System.out.println("Can't read data error " /*+*/);
            return;
        }

        showAssets();

        InvestmentAccount account = new InvestmentAccount();
        try (Scanner scnr = new Scanner(System.in)) {
            while (true) {
            	System.out.println();
                System.out.print("Enter the amount to invest in dollars: ");
                int amount;
                
                try {
                    amount = scnr.nextInt();
                } catch (InputMismatchException ex) {
                	System.out.println();
                    System.out.println("Invalid input! Please enter an amount without decimals.");
                    scnr.next();
                    continue;
                }

                if (amount < 0) {
                	writeToFile(account);
                	showInvestments(account, null, true);
                    break;
                }
                
                System.out.println();
                System.out.print("Enter the asset symbol to invest in: ");
                String assetSymbol = scnr.next();

                Asset choice = allAssets.stream().filter(a -> a.getSymbol().equals(assetSymbol)).findFirst().orElse(null);

                if (choice == null) {
                	System.out.println();
                    System.out.println(assetSymbol + " is not a valid Asset symbol. Choose from the list only.");
                    continue;
                }

                Investment investment = new Investment(choice, amount, 10);
                account.addInvestments(investment);
                System.out.println();
                System.out.printf("Investing %d in %s has an expected future value of: %d\n", amount, choice.getSymbol(), investment.getReturnsValue());
            }
        }
    }
}